import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { user, logout } = useAuth(); 

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.pageYOffset > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`fixed top-0 left-0 right-0 bg-luxury-surface border-b border-luxury-border z-50 transition-all duration-300 ${isScrolled ? 'shadow-2xl' : ''}`}>
      <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-3" onClick={closeMenu}>
          <div className="bg-luxury-accent text-luxury-bg w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center font-bold text-lg sm:text-xl shadow-lg">
            JH
          </div>
          <span className="text-xl sm:text-2xl font-bold font-display text-luxury-text tracking-wide">
            Jhankar Hotel
          </span>
        </Link>

        <ul className="hidden lg:flex items-center space-x-8">
          <li><a href="/#home" className="text-luxury-muted hover:text-luxury-accent transition font-medium">Home</a></li>
          <li><a href="/#about" className="text-luxury-muted hover:text-luxury-accent transition font-medium">About Us</a></li>
          <li><a href="/#rooms" className="text-luxury-muted hover:text-luxury-accent transition font-medium">Rooms</a></li>
          <li><a href="/#gallery" className="text-luxury-muted hover:text-luxury-accent transition font-medium">Gallery</a></li>
        </ul>

        <div className="flex items-center space-x-2 sm:space-x-4">
          {user ? (
            <>
              {user.role !== 'admin' && (
                <Link to="/profile" onClick={closeMenu} className="bg-luxury-accent/10 text-luxury-accent px-3 py-1.5 rounded-md font-semibold text-sm transition hover:bg-luxury-accent/20 hidden sm:block border border-luxury-accent/20">
                  <i className="fas fa-user-circle mr-2"></i>My Profile
                </Link>
              )}
              <Link to="/booking" onClick={closeMenu} className="text-luxury-muted hover:text-luxury-accent font-semibold text-sm transition hidden sm:block">
                Book Room
              </Link>
              <Link to="/order" onClick={closeMenu} className="text-luxury-muted hover:text-luxury-accent font-semibold text-sm transition hidden sm:block">
                Order Food
              </Link>
              
              <div className="text-luxury-text px-3 py-1.5 rounded-md font-semibold text-sm hidden md:block">
                Hi, <span className="text-luxury-accent">{user.username}</span>
              </div>
              
              {user.role === 'admin' && (
                <Link to="/admin" onClick={closeMenu} className="bg-white/10 hover:bg-white/20 text-luxury-text px-3 py-1.5 rounded-md font-semibold text-sm transition shadow-md hidden sm:block">
                  Dashboard
                </Link>
              )}
              
              <button onClick={() => { logout(); closeMenu(); }} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-md font-semibold text-sm transition shadow-md">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" onClick={closeMenu} className="text-luxury-muted hover:text-luxury-accent font-semibold text-sm transition">
                Log In
              </Link>
              <Link to="/register" onClick={closeMenu} className="bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg px-3 py-1.5 sm:px-4 sm:py-2 rounded-md font-bold text-sm sm:text-base transition shadow-lg hover:shadow-xl">
                Create Account
              </Link>
            </>
          )}

          <button
            id="mobileMenuBtn"
            className="lg:hidden text-2xl text-luxury-muted hover:text-luxury-accent"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
          </button>
        </div>
      </nav>

      <div id="mobileMenu" className={`lg:hidden bg-luxury-surface border-t border-luxury-border ${isMenuOpen ? 'block' : 'hidden'}`}>
        <ul className="container mx-auto px-4 py-3 space-y-2 text-luxury-muted">
          <li><a href="/#home" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">Home</a></li>
          <li><a href="/#about" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">About Us</a></li>
          <li><a href="/#rooms" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">Rooms</a></li>
          <li><a href="/#gallery" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">Gallery</a></li>
          {user && (
            <>
              {user.role !== 'admin' && <li><Link to="/profile" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">My Profile</Link></li>}
              <li><Link to="/booking" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">Book Room</Link></li>
              <li><Link to="/order" onClick={closeMenu} className="block hover:text-luxury-accent transition font-medium">Order Food</Link></li>
              {user.role === 'admin' && <li><Link to="/admin" onClick={closeMenu} className="block text-luxury-accent transition font-medium">Admin Dashboard</Link></li>}
            </>
          )}
        </ul>
      </div>
    </header>
  );
};

export default Header;