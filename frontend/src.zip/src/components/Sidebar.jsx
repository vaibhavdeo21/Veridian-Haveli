import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import ChangePasswordModal from './ChangePasswordModal.jsx'; 

const SidebarLink = ({ to, icon, children }) => {
    return (
        <li>
            <NavLink
                to={to}
                end
                className={({ isActive }) =>
                    `sidebar-item flex items-center p-3 rounded-lg transition-colors border-l-4 ${
                        isActive 
                        ? 'bg-luxury-accent/10 text-luxury-accent border-luxury-accent font-bold' 
                        : 'border-transparent text-luxury-muted hover:bg-white/5 hover:text-luxury-accent'
                    }`
                }
            >
                <i className={`fas ${icon} w-6 text-center text-lg`}></i>
                <span className="ml-3 whitespace-nowrap">{children}</span>
            </NavLink>
        </li>
    );
};

const Sidebar = ({ isOpen }) => {
    const { logout, user } = useAuth();
    const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

    return (
        <>
            <aside
                className={`fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-luxury-surface border-r border-luxury-border shadow-2xl z-40 transition-transform duration-300 ${
                    isOpen ? 'translate-x-0' : '-translate-x-full'
                }`}
            >
                <div className="h-full flex flex-col justify-between p-4 overflow-y-auto">
                    <div>
                        <div className="flex items-center space-x-3 p-2 mb-4 border-b border-luxury-border pb-4">
                            <div className="w-12 h-12 bg-luxury-accent/20 text-luxury-accent rounded-full flex items-center justify-center shrink-0">
                                <i className="fas fa-user text-xl"></i>
                            </div>
                            <div className="block">
                                <span className="font-medium text-luxury-text block">{user?.username || 'Admin User'}</span>
                                <span className="text-sm text-luxury-muted block">Administrator</span>
                            </div>
                        </div>

                        <nav>
                            <ul className="space-y-2">
                                <SidebarLink to="/admin" icon="fa-tachometer-alt">Dashboard</SidebarLink>
                                <SidebarLink to="/admin/rooms" icon="fa-bed">Booking Rooms</SidebarLink>
                                <SidebarLink to="/admin/offline-booking" icon="fa-calendar-plus">Offline Booking</SidebarLink>
                                <SidebarLink to="/admin/orders" icon="fa-utensils">Order Food</SidebarLink>
                                <SidebarLink to="/admin/customers" icon="fa-users">Customers</SidebarLink>                                
                                <SidebarLink to="/admin/update-menu" icon="fa-edit">Update Menu</SidebarLink>
                            </ul>
                        </nav>
                    </div>

                    <div className="pt-4 border-t border-luxury-border space-y-2">
                        <button
                            onClick={() => setIsPasswordModalOpen(true)}
                            className="w-full flex items-center p-3 text-luxury-muted hover:bg-white/5 hover:text-luxury-accent rounded-lg transition-colors"
                        >
                            <i className="fas fa-key w-6 text-center text-lg"></i>
                            <span className="ml-3 font-semibold">Change Password</span>
                        </button>

                        <button
                            onClick={logout}
                            className="w-full flex items-center p-3 text-red-500 hover:bg-red-500/10 hover:text-red-400 rounded-lg transition-colors"
                        >
                            <i className="fas fa-sign-out-alt w-6 text-center text-lg"></i>
                            <span className="ml-3 font-semibold">Sign Out</span>
                        </button>
                    </div>
                </div>
            </aside>

            <ChangePasswordModal
                isOpen={isPasswordModalOpen}
                onClose={() => setIsPasswordModalOpen(false)}
            />
        </>
    );
};

export default Sidebar;