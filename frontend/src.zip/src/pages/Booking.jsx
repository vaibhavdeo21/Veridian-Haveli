import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { useNotification } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';

const roomConfig = {
  single: { name: 'Single Bed Room', price: 2500 },
  double: { name: 'Double Bed Room', price: 4000 },
  triple: { name: 'Triple Bed Room', price: 5500 },
  dormitory: { name: 'Dormitory Bed', price: 1200 },
};

const TAX_RATE = 0.18;

const getToday = () => new Date().toISOString().split('T')[0];
const getTomorrow = () => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  return tomorrow.toISOString().split('T')[0];
};

const Booking = () => {
  const { addCustomer, rooms, customers } = useData();
  const { showNotification } = useNotification();
  const { user, updateActiveBooking } = useAuth();

  const [currentStep, setCurrentStep] = useState(1);
  const [dates, setDates] = useState({
    checkIn: getToday(),
    checkOut: getTomorrow(),
  });
  const [selectedRooms, setSelectedRooms] = useState({
    single: 0,
    double: 0,
    triple: 0,
    dormitory: 0,
  });
  const [guestDetails, setGuestDetails] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    requests: '',
  });

  const isRepeatCustomer = useMemo(() => {
    if (!user || !customers) return false;
    return customers.some(c => 
      c.email === user.email || 
      c.username === user.username
    );
  }, [user, customers]);

  const roomAvailability = useMemo(() => {
    const counts = { single: 0, double: 0, triple: 0, dormitory: 0 };
    if (Array.isArray(rooms)) {
      rooms.forEach(room => {
        const isAvailable = !room.availability || room.availability.toLowerCase() === 'available';
        if (isAvailable) {
          const type = (room.type || '').toLowerCase();
          if (type.includes('single')) counts.single++;
          else if (type.includes('double')) counts.double++;
          else if (type.includes('triple')) counts.triple++;
          else if (type.includes('dorm')) counts.dormitory++;
        }
      });
    }
    return counts;
  }, [rooms]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentStep]);

  const nights = useMemo(() => {
    if (!dates.checkIn || !dates.checkOut) return 0;
    const checkIn = new Date(dates.checkIn);
    const checkOut = new Date(dates.checkOut);
    const timeDiff = checkOut.getTime() - checkIn.getTime();
    const nightsCount = Math.ceil(timeDiff / (1000 * 3600 * 24));
    return nightsCount > 0 ? nightsCount : 0;
  }, [dates]);

  const roomTotals = useMemo(() => {
    let roomTotal = 0;
    const details = {};
    for (const [key, quantity] of Object.entries(selectedRooms)) {
      if (quantity > 0) {
        const price = roomConfig[key].price;
        const subtotal = price * quantity * nights;
        roomTotal += subtotal;
        details[key] = {
          ...roomConfig[key],
          quantity,
          subtotal,
          baseType: key 
        };
      }
    }
    return { roomTotal, details };
  }, [selectedRooms, nights]);

  const finalTotals = useMemo(() => {
    const { roomTotal } = roomTotals;
    const discountAmount = isRepeatCustomer ? (roomTotal * 0.05) : 0;
    const discountedRoomTotal = roomTotal - discountAmount;

    const tax = discountedRoomTotal * TAX_RATE;
    const grandTotal = discountedRoomTotal + tax;

    return { roomTotal, discountAmount, discountedRoomTotal, tax, grandTotal };
  }, [roomTotals, isRepeatCustomer]);

  if (!user) {
    return (
      <main className="pt-32 pb-16 text-center min-h-[70vh] flex flex-col items-center justify-center bg-luxury-bg">
        <div className="bg-luxury-surface border border-luxury-border p-8 rounded-xl shadow-2xl max-w-lg w-full">
          <i className="fas fa-lock text-5xl text-luxury-accent mb-4"></i>
          <h2 className="text-3xl font-bold font-display text-luxury-text mb-2">Login Required</h2>
          <p className="text-luxury-muted mb-8">You must have an account and be logged in to book a room at Jhankar Hotel.</p>
          <div className="flex flex-col space-y-3">
            <Link to="/login" className="bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg px-8 py-3 rounded-lg font-bold transition">
              Log In
            </Link>
            <Link to="/register" className="bg-white/10 hover:bg-white/20 text-luxury-text px-8 py-3 rounded-lg font-bold transition">
              Create an Account
            </Link>
          </div>
        </div>
      </main>
    );
  }

  const handleDateChange = (e) => {
    const { id, value } = e.target;
    const newDates = { ...dates, [id]: value };
    if (id === 'checkIn' && newDates.checkOut < value) {
      newDates.checkOut = value;
    }
    setDates(newDates);
  };

  const handleRoomChange = (roomType, quantity) => {
    const maxAvailable = roomAvailability[roomType];
    if (quantity >= 0 && quantity <= maxAvailable) {
      setSelectedRooms(prev => ({ ...prev, [roomType]: quantity }));
    } else if (quantity > maxAvailable) {
      showNotification(`Only ${maxAvailable} ${roomType} rooms are currently available.`, 'error');
    }
  };

  const handleGuestChange = (e) => {
    const { id, value } = e.target;
    setGuestDetails(prev => ({ ...prev, [id]: value }));
  };

  const goToStep = (step) => {
    setCurrentStep(step);
  };

  const handleNextToGuest = () => {
    if (roomTotals.roomTotal <= 0) {
      showNotification('Please select at least one available room and stay dates.', 'error');
      return;
    }
    goToStep(2);
  };

  const handleNextToReview = () => {
    if (!guestDetails.firstName || !guestDetails.lastName || !guestDetails.email || !guestDetails.phone) {
      showNotification('Please fill in all required guest details.', 'error');
      return;
    }
    goToStep(3);
  };

  const handleConfirmBooking = async (paymentMode, amountPaid) => {
    let success = true;
    const finalGuestDetails = {
      ...guestDetails,
      username: user.username,
      checkIn: dates.checkIn,
      checkOut: dates.checkOut,
      isRepeatCustomer: isRepeatCustomer
    };

    for (const [key, data] of Object.entries(roomTotals.details)) {
      if (data.quantity > 0) {
        for (let i = 0; i < data.quantity; i++) {
          const roomData = {
            baseType: data.baseType, 
            type: data.name,
            totalAmount: (data.subtotal / data.quantity) * (1 + TAX_RATE) 
          };

          const perRoomPaid = amountPaid / (Object.values(roomTotals.details).reduce((sum, d) => sum + d.quantity, 0));

          try {
            await addCustomer(finalGuestDetails, roomData, paymentMode, perRoomPaid);
          } catch (error) {
            success = false;
          }
        }
      }
    }

    if (success) {
      updateActiveBooking('Online');
      showNotification(`Thank you! Your booking is confirmed. Mode: ${paymentMode.replace(/([A-Z])/g, ' $1').trim()}`, 'success');
      setSelectedRooms({ single: 0, double: 0, triple: 0, dormitory: 0 });
      setDates({ checkIn: getToday(), checkOut: getTomorrow() });
      setGuestDetails({ firstName: '', lastName: '', email: '', phone: '', address: '', city: '', state: '', zip: '', requests: '' });
      goToStep(1);
    } else {
      showNotification('Some bookings failed. Please contact support.', 'error');
    }
  };

  return (
    <main className="pt-28 pb-16 bg-luxury-bg min-h-screen">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 font-display text-luxury-text">Book Your Stay</h1>
          <p className="text-luxury-muted max-w-2xl mx-auto">Select from real-time available rooms managed by our front desk</p>
          <p className="text-xs font-bold mt-2 text-luxury-accent">Check-in: 12:00 PM | Check-out: 11:00 AM</p>
        </div>

        <div className="mb-12">
          <div className="flex items-center justify-between max-w-3xl mx-auto relative">
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-luxury-border -translate-y-1/2 z-0"></div>
            <div
              className="absolute top-1/2 left-0 h-0.5 bg-luxury-accent -translate-y-1/2 z-0 transition-all duration-500"
              style={{ width: `${(currentStep - 1) * 50}%` }}
            ></div>

            {[
              { s: 1, l: "Select Rooms" },
              { s: 2, l: "Guest Details" },
              { s: 3, l: "Review & Pay" }
            ].map((item) => (
              <div key={item.s} className="relative z-10 flex flex-col items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${currentStep >= item.s ? 'bg-luxury-accent text-luxury-bg shadow-[0_0_15px_rgba(201,168,106,0.5)]' : 'bg-luxury-surface text-luxury-muted border border-luxury-border'}`}>
                  {currentStep > item.s ? <i className="fas fa-check"></i> : item.s}
                </div>
                <span className={`mt-2 text-xs md:text-sm font-bold tracking-wide uppercase ${currentStep >= item.s ? 'text-luxury-accent' : 'text-luxury-muted'}`}>
                  {item.l}
                </span>
              </div>
            ))}
          </div>
        </div>

        {currentStep === 1 && (
          <div className="animate-fadeIn">
            <h2 className="text-3xl font-bold mb-8 font-display text-center text-luxury-text">Choose Your Accommodation</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {Object.entries(roomConfig).map(([key, config]) => (
                <RoomSelectionCard
                  key={key}
                  roomType={key}
                  config={config}
                  quantity={selectedRooms[key]}
                  onRoomChange={handleRoomChange}
                  subtotal={roomTotals.details[key]?.subtotal || 0}
                  availableCount={roomAvailability[key]}
                />
              ))}
            </div>

            <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-6 mb-8">
              <h3 className="text-xl font-bold mb-4 font-display text-luxury-text">Select Your Stay Dates</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-luxury-muted">Check-in Date</label>
                  <input type="date" id="checkIn" value={dates.checkIn} min={getToday()} onChange={handleDateChange} className="w-full px-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent custom-date-picker" />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-luxury-muted">Check-out Date</label>
                  <input type="date" id="checkOut" value={dates.checkOut} min={dates.checkIn} onChange={handleDateChange} className="w-full px-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent custom-date-picker" />
                </div>
              </div>
              <div className="mt-6 text-sm font-bold text-luxury-accent bg-luxury-accent/10 border border-luxury-accent/20 py-2 px-4 rounded-lg inline-block">
                Total Nights: {nights}
              </div>
            </div>

            <RoomSummaryTable roomTotals={roomTotals} nights={nights} />

            <div className="flex justify-between mt-8">
              <Link to="/" className="bg-white/5 hover:bg-white/10 text-luxury-text px-8 py-3 rounded-lg font-bold transition">
                <i className="fas fa-arrow-left mr-2"></i>Back to Home
              </Link>
              <button
                disabled={roomTotals.roomTotal === 0}
                onClick={handleNextToGuest}
                className={`px-8 py-3 rounded-lg font-bold transition flex items-center ${roomTotals.roomTotal > 0 ? 'bg-luxury-accent text-luxury-bg hover:bg-luxury-accentHover shadow-lg' : 'bg-white/5 text-luxury-muted cursor-not-allowed'}`}
              >
                Continue to Details <i className="fas fa-arrow-right ml-2"></i>
              </button>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="animate-fadeIn max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 font-display text-center text-luxury-text">Guest Information</h2>
            <GuestForm guestDetails={guestDetails} onChange={handleGuestChange} />
            <div className="flex justify-between mt-8">
              <button onClick={() => goToStep(1)} className="bg-white/5 hover:bg-white/10 text-luxury-text px-8 py-3 rounded-lg font-bold transition">
                <i className="fas fa-arrow-left mr-2"></i>Back to Rooms
              </button>
              <button onClick={handleNextToReview} className="bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg px-8 py-3 rounded-lg font-bold transition shadow-lg">
                Review & Payment <i className="fas fa-arrow-right ml-2"></i>
              </button>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="animate-fadeIn max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 font-display text-center text-luxury-text">Review Your Booking</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <BookingReview dates={dates} nights={nights} roomTotals={roomTotals} finalTotals={finalTotals} guest={guestDetails} />
              <PaymentForm finalTotals={finalTotals} onConfirm={handleConfirmBooking} />
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={() => goToStep(2)} className="bg-white/5 hover:bg-white/10 text-luxury-text px-8 py-3 rounded-lg font-bold transition">
                <i className="fas fa-arrow-left mr-2"></i>Back to Guest Details
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

// --- Sub-Components ---

const RoomSelectionCard = ({ roomType, config, quantity, onRoomChange, subtotal, availableCount }) => (
  <div className="room-card bg-luxury-surface border border-luxury-border rounded-xl shadow-xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:border-luxury-accent/50 group">
    <div className="relative">
      <img src={`https://images.unsplash.com/${config.price === 2500 ? 'photo-1631049307264-da0ec9d70304' : config.price === 4000 ? 'photo-1566665797739-1674de7a421a' : config.price === 5500 ? 'photo-1611892440504-42a792e24d32' : 'photo-1590490360182-c33d57733427'}?w=400&h=300&fit=crop`} alt={config.name} className="w-full h-48 object-cover group-hover:scale-105 transition duration-700" />
      <div className="absolute inset-0 bg-gradient-to-t from-luxury-surface via-transparent to-transparent opacity-80"></div>
      <div className="absolute top-4 right-4 bg-luxury-accent text-luxury-bg text-sm font-bold px-3 py-1 rounded-full shadow-lg">
        ₹{config.price.toLocaleString()} / night
      </div>
    </div>
    <div className="p-6 relative z-10">
      <h3 className="text-lg font-bold text-luxury-text mb-4 h-12 leading-tight">{config.name}</h3>
      <div className="flex justify-between items-center mb-4">
        <span className={`text-xs font-bold uppercase tracking-tighter ${availableCount > 0 ? 'text-green-400' : 'text-red-400'}`}>
          {availableCount > 0 ? `Available Units: ${availableCount}` : 'Fully Booked'}
        </span>
        <div className="flex items-center space-x-3 bg-luxury-bg rounded-lg p-1 border border-luxury-border">
          <button onClick={() => onRoomChange(roomType, quantity - 1)} className="w-8 h-8 flex items-center justify-center rounded text-luxury-accent hover:bg-white/5 transition">-</button>
          <span className="font-bold text-luxury-text w-4 text-center">{quantity}</span>
          <button onClick={() => onRoomChange(roomType, quantity + 1)} className="w-8 h-8 flex items-center justify-center rounded text-luxury-accent hover:bg-white/5 transition">+</button>
        </div>
      </div>
      <div className="text-right border-t border-luxury-border pt-4">
        <span className="text-luxury-accent font-black">Subtotal: ₹{subtotal.toLocaleString()}</span>
      </div>
    </div>
  </div>
);

const RoomSummaryTable = ({ roomTotals, nights }) => (
  <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-6 mb-8">
    <h3 className="text-xl font-bold mb-6 font-display text-luxury-text flex items-center">
      <i className="fas fa-list-ul mr-3 text-luxury-accent"></i>Room Booking Summary
    </h3>
    <div className="overflow-x-auto">
      <table className="w-full text-luxury-text">
        <thead>
          <tr className="text-left text-xs font-bold text-luxury-muted uppercase tracking-widest border-b border-luxury-border">
            <th className="pb-4">Room Type</th>
            <th className="pb-4 text-center">Quantity</th>
            <th className="pb-4 text-right">Price/Night</th>
            <th className="pb-4 text-right">Subtotal</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-luxury-border">
          {Object.keys(roomTotals.details).length > 0 ? (
            Object.entries(roomTotals.details).map(([key, data]) => (
              <tr key={key}>
                <td className="py-4 font-bold">{data.name}</td>
                <td className="py-4 text-center font-semibold text-luxury-muted">{data.quantity}</td>
                <td className="py-4 text-right text-luxury-muted">₹{data.price.toLocaleString()}</td>
                <td className="py-4 text-right font-black text-luxury-accent">₹{data.subtotal.toLocaleString()}</td>
              </tr>
            ))
          ) : (
            <tr><td colSpan="4" className="py-8 text-center text-luxury-muted italic">No rooms selected yet. Use the cards above to start.</td></tr>
          )}
        </tbody>
        <tfoot>
          <tr className="border-t-2 border-luxury-border">
            <td colSpan="3" className="py-4 text-right font-bold text-luxury-muted">Room Total (per night):</td>
            <td className="py-4 text-right font-black text-luxury-text text-lg">₹{(roomTotals.roomTotal / (nights || 1)).toLocaleString()}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
);

const GuestForm = ({ guestDetails, onChange }) => (
  <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-8 mb-8">
    <h3 className="text-2xl font-bold mb-8 font-display text-luxury-text flex items-center">
      <i className="fas fa-user-edit mr-3 text-luxury-accent"></i>Primary Guest Details
    </h3>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
      <FormInput label="First Name" id="firstName" value={guestDetails.firstName} onChange={onChange} required placeholder="Rahul" />
      <FormInput label="Last Name" id="lastName" value={guestDetails.lastName} onChange={onChange} required placeholder="Sharma" />
      <FormInput label="Email Address" id="email" type="email" value={guestDetails.email} onChange={onChange} required placeholder="rahul@example.com" />
      <FormInput label="Phone Number" id="phone" type="tel" value={guestDetails.phone} onChange={onChange} required placeholder="+91 ..." />
    </div>
    <div className="mb-2">
      <label className="block text-sm font-bold text-luxury-muted mb-3">Special Requests or Instructions</label>
      <textarea id="requests" value={guestDetails.requests} onChange={onChange} className="w-full px-4 py-4 bg-luxury-bg border border-luxury-border text-luxury-text rounded-xl focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent transition-all placeholder-luxury-border" rows="4" placeholder="Mention any extra needs like extra towels, early check-in, etc."></textarea>
    </div>
  </div>
);

const FormInput = ({ label, id, type = 'text', value, onChange, required = false, placeholder = '' }) => (
  <div>
    <label className="block text-sm font-bold text-luxury-muted mb-3">{label}{required && ' *'}</label>
    <input
      type={type}
      id={id}
      value={value}
      onChange={onChange}
      className="w-full px-4 py-4 bg-luxury-bg border border-luxury-border text-luxury-text rounded-xl focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent transition-all placeholder-luxury-border"
      required={required}
      placeholder={placeholder}
    />
  </div>
);

const BookingReview = ({ dates, nights, roomTotals, finalTotals, guest }) => (
  <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-8 h-full flex flex-col">
    <h3 className="text-2xl font-bold mb-8 font-display text-luxury-text border-b border-luxury-border pb-4">
      Stay Summary
    </h3>
    <div className="space-y-6 flex-grow">
      <div className="flex justify-between"><span className="text-luxury-muted">Guest Name:</span><span className="font-bold text-luxury-text">{guest.firstName} {guest.lastName}</span></div>
      <div className="flex justify-between items-center">
        <div>
          <h4 className="text-xs font-black text-luxury-muted uppercase tracking-widest mb-1">Check-in</h4>
          <p className="font-bold text-luxury-text">{dates.checkIn}</p>
        </div>
        <div className="text-luxury-accent"><i className="fas fa-long-arrow-alt-right text-2xl"></i></div>
        <div className="text-right">
          <h4 className="text-xs font-black text-luxury-muted uppercase tracking-widest mb-1">Check-out</h4>
          <p className="font-bold text-luxury-text">{dates.checkOut}</p>
        </div>
      </div>

      <div className="bg-luxury-bg border border-luxury-border p-4 rounded-xl flex justify-between items-center">
        <span className="text-sm font-bold text-luxury-muted">Stay Duration</span>
        <span className="font-black text-luxury-accent">{nights} Nights</span>
      </div>

      <div className="space-y-4 pt-4 border-t border-luxury-border">
        {Object.entries(roomTotals.details).map(([key, data]) => (
          <div key={key} className="flex justify-between text-sm">
            <span className="font-bold text-luxury-muted">{data.name} x {data.quantity}</span>
            <span className="font-black text-luxury-text">₹{data.subtotal.toLocaleString()}</span>
          </div>
        ))}
      </div>

      <div className="border-t border-luxury-border pt-6 space-y-3 mt-auto">
        {/* REPEAT CUSTOMER DISCOUNT DISPLAY */}
        {finalTotals.discountAmount > 0 && (
          <div className="flex justify-between text-sm text-green-400 font-bold bg-green-500/10 p-3 rounded-lg border border-green-500/20">
            <span><i className="fas fa-award mr-2"></i>Repeat Customer Discount (5%)</span>
            <span>- ₹{finalTotals.discountAmount.toLocaleString()}</span>
          </div>
        )}
        
        <div className="flex justify-between font-black text-2xl text-luxury-accent pt-2 border-t border-dashed border-luxury-border">
          <span>Total Bill</span>
          <span>₹{finalTotals.grandTotal.toLocaleString()}</span>
        </div>
      </div>
    </div>
  </div>
);

const PaymentForm = ({ finalTotals, onConfirm }) => {
  const [paymentMode, setPaymentMode] = useState('OnlineFull');
  const [method, setMethod] = useState('Credit Card');

  const amountToPay = paymentMode === 'OnlineFull'
    ? finalTotals.grandTotal
    : paymentMode === 'OnlinePartial'
      ? finalTotals.grandTotal / 2
      : 0;

  return (
    <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-8 flex flex-col h-full">
      <h3 className="text-2xl font-bold mb-6 font-display text-luxury-text border-b border-luxury-border pb-4">
        <i className="fas fa-shield-alt mr-3 text-luxury-accent"></i>Secure Payment
      </h3>

      <div className="space-y-4 mb-6">
        {/* Full Payment */}
        <div
          onClick={() => setPaymentMode('OnlineFull')}
          className={`border-2 rounded-xl p-4 cursor-pointer transition ${paymentMode === 'OnlineFull' ? 'border-green-500 bg-green-500/10' : 'border-luxury-border hover:border-luxury-muted bg-luxury-bg'}`}
        >
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <input type="radio" checked={paymentMode === 'OnlineFull'} readOnly className="accent-green-500" />
              <span className="font-bold text-luxury-text">Pay Full Amount</span>
            </div>
            <span className="font-black text-green-400">₹{finalTotals.grandTotal.toLocaleString()}</span>
          </div>
          <p className="text-xs text-luxury-muted mt-2 ml-7">Room is instantly locked and assigned.</p>
        </div>

        {/* 50% Advance */}
        <div
          onClick={() => setPaymentMode('OnlinePartial')}
          className={`border-2 rounded-xl p-4 cursor-pointer transition ${paymentMode === 'OnlinePartial' ? 'border-blue-500 bg-blue-500/10' : 'border-luxury-border hover:border-luxury-muted bg-luxury-bg'}`}
        >
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <input type="radio" checked={paymentMode === 'OnlinePartial'} readOnly className="accent-blue-500" />
              <span className="font-bold text-luxury-text">Pay 50% Advance</span>
            </div>
            <span className="font-black text-blue-400">₹{(finalTotals.grandTotal / 2).toLocaleString()}</span>
          </div>
          <p className="text-xs text-luxury-muted mt-2 ml-7">Room is instantly locked and assigned. Pay rest at check-in.</p>
        </div>

        {/* Pay at Hotel */}
        <div
          onClick={() => setPaymentMode('PayAtHotel')}
          className={`border-2 rounded-xl p-4 cursor-pointer transition ${paymentMode === 'PayAtHotel' ? 'border-luxury-accent bg-luxury-accent/10' : 'border-luxury-border hover:border-luxury-muted bg-luxury-bg'}`}
        >
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <input type="radio" checked={paymentMode === 'PayAtHotel'} readOnly className="accent-luxury-accent" />
              <span className="font-bold text-luxury-text">Pay at Hotel</span>
            </div>
            <span className="font-black text-luxury-muted">₹0 Now</span>
          </div>
          {paymentMode === 'PayAtHotel' && (
            <div className="mt-4 ml-7 bg-red-500/10 text-red-400 p-3 rounded-lg text-xs font-bold leading-relaxed border border-red-500/20">
              <i className="fas fa-exclamation-triangle mr-2"></i>
              You are choosing Pay at Hotel. Room availability is subject to availability at the time of arrival. To confirm and lock your room, please pay an advance now.
            </div>
          )}
        </div>
      </div>

      {paymentMode !== 'PayAtHotel' && (
        <div className="mb-6 animate-fadeIn">
          <label className="block text-xs font-black text-luxury-muted uppercase tracking-widest mb-3">Online Payment Method</label>
          <div className="grid grid-cols-4 gap-2">
            {[
              { m: 'Card', i: 'fa-credit-card' },
              { m: 'GPay', i: 'fab fa-google-pay' },
              { m: 'UPI', i: 'fa-mobile-alt' },
              { m: 'Wallet', i: 'fa-wallet' }
            ].map(item => (
              <div
                key={item.m}
                onClick={() => setMethod(item.m)}
                className={`border-2 rounded-lg py-2 text-center cursor-pointer transition-all ${method === item.m ? 'border-green-500 bg-green-500/10 text-green-400' : 'border-luxury-border bg-luxury-bg text-luxury-muted hover:border-luxury-muted'}`}
              >
                <i className={`fas ${item.i} text-lg mb-1`}></i>
                <p className="text-[9px] font-black uppercase">{item.m}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-auto pt-4">
        <button
          onClick={() => onConfirm(paymentMode, amountToPay)}
          className={`w-full py-4 rounded-xl font-black text-lg transition shadow-xl hover:scale-[1.02] active:scale-[0.98] ${paymentMode === 'PayAtHotel' ? 'bg-white/10 hover:bg-white/20 text-luxury-text border border-luxury-border' : 'bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg'}`}
        >
          {paymentMode === 'PayAtHotel' ? (
            <>RESERVE WITHOUT LOCKING</>
          ) : (
            <><i className="fas fa-lock mr-2"></i>CONFIRM & PAY ₹{amountToPay.toLocaleString()}</>
          )}
        </button>
      </div>
    </div>
  );
};

export default Booking;