import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const Register = () => {
  const [details, setDetails] = useState({ username: '', email: '', password: '' });
  const { register } = useAuth();

  const handleSubmit = (e) => {
    e.preventDefault();
    register(details);
  };

  return (
    <main className="pt-32 pb-16 min-h-screen bg-luxury-bg flex items-center justify-center">
      <div className="bg-luxury-surface border border-luxury-border p-8 rounded-2xl shadow-2xl max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-luxury-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-user-plus text-luxury-accent text-3xl"></i>
          </div>
          <h2 className="text-3xl font-bold font-display text-luxury-text">Create Account</h2>
          <p className="text-luxury-muted mt-2">Join Jhankar Hotel for exclusive amenities</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold mb-1 text-luxury-muted">Username</label>
            <div className="relative">
              <i className="fas fa-user absolute left-4 top-3.5 text-luxury-muted"></i>
              <input 
                type="text" 
                className="w-full pl-10 pr-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent"
                placeholder="Choose a username"
                value={details.username}
                onChange={(e) => setDetails({...details, username: e.target.value})}
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1 text-luxury-muted">Email</label>
            <div className="relative">
              <i className="fas fa-envelope absolute left-4 top-3.5 text-luxury-muted"></i>
              <input 
                type="email" 
                className="w-full pl-10 pr-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent"
                placeholder="Enter your email"
                value={details.email}
                onChange={(e) => setDetails({...details, email: e.target.value})}
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1 text-luxury-muted">Password</label>
            <div className="relative">
              <i className="fas fa-lock absolute left-4 top-3.5 text-luxury-muted"></i>
              <input 
                type="password" 
                className="w-full pl-10 pr-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent"
                placeholder="Create a password"
                value={details.password}
                onChange={(e) => setDetails({...details, password: e.target.value})}
                required
              />
            </div>
          </div>
          <button 
            type="submit" 
            className="w-full bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg font-bold py-3 px-4 rounded-lg transition duration-300 flex items-center justify-center mt-4 shadow-lg"
          >
            <i className="fas fa-check-circle mr-2"></i> Sign Up
          </button>
        </form>
        
        <div className="mt-6 text-center text-sm text-luxury-muted border-t border-luxury-border pt-6">
          Already have an account? <br/>
          <Link to="/login" className="text-luxury-accent font-bold hover:text-luxury-accentHover mt-2 inline-block transition">Log In Here</Link>
        </div>
      </div>
    </main>
  );
};

export default Register;