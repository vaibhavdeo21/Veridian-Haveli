import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext.jsx'; 
import { useAuth } from '../context/AuthContext.jsx';

const SERVICE_CHARGE_RATE = 0.05;

const Order = () => {
  const { foodMenu, addOrder } = useData(); 
  const { user } = useAuth(); 
  
  const [activeCategory, setActiveCategory] = useState('breakfast');
  const [cart, setCart] = useState({});
  const [guestInfo, setGuestInfo] = useState({ roomNumber: '', guestName: '', specialInstructions: '' });
  const [isModalOpen, setIsModalOpen] = useState(false);

  if (!user) {
    return (
      <main className="pt-32 pb-16 text-center min-h-[70vh] flex flex-col items-center justify-center bg-luxury-bg">
        <div className="bg-luxury-surface p-8 rounded-xl shadow-2xl max-w-lg w-full border-t-4 border-luxury-accent">
          <i className="fas fa-lock text-5xl text-luxury-accent mb-4"></i>
          <h2 className="text-3xl font-bold font-display text-luxury-text mb-2">Login Required</h2>
          <p className="text-luxury-muted mb-8">Please log in to access Room Service.</p>
          <Link to="/login" className="bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg px-8 py-3 rounded-lg font-bold transition inline-block w-full">
            Log In Now
          </Link>
        </div>
      </main>
    );
  }

  if (user.role !== 'admin' && !user.activeBooking) {
    return (
      <main className="pt-32 pb-16 text-center min-h-[70vh] flex flex-col items-center justify-center bg-luxury-bg">
        <div className="bg-luxury-surface p-8 rounded-xl shadow-2xl max-w-lg w-full border-t-4 border-red-500">
          <i className="fas fa-bed text-5xl text-luxury-muted mb-4"></i>
          <h2 className="text-3xl font-bold font-display text-luxury-text mb-2">Active Booking Required</h2>
          <p className="text-luxury-muted mb-8">You must have an active room booking to order food to your room. This is a guest-only amenity.</p>
          <Link to="/booking" className="bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg px-8 py-3 rounded-lg font-bold transition inline-block w-full">
            Book a Room Now
          </Link>
        </div>
      </main>
    );
  }

  const handleCategoryToggle = (key) => {
    setActiveCategory(activeCategory === key ? null : key);
  };

  const handleQuantityChange = (item, quantity) => {
    if (quantity < 0) return;
    setCart(prev => {
      const newCart = { ...prev };
      if (quantity === 0) {
        delete newCart[item.id];
      } else {
        newCart[item.id] = { ...item, quantity };
      }
      return newCart;
    });
  };

  const totals = useMemo(() => {
    let foodTotal = 0;
    for (const item of Object.values(cart)) {
      foodTotal += item.price * item.quantity;
    }
    const serviceCharge = foodTotal * SERVICE_CHARGE_RATE;
    const grandTotal = foodTotal + serviceCharge;
    return { foodTotal, serviceCharge, grandTotal };
  }, [cart]);

  const handlePlaceOrder = () => {
    if (!guestInfo.roomNumber || !guestInfo.guestName) {
      alert('Please enter your Room Number and Guest Name.');
      return;
    }
    if (Object.keys(cart).length === 0) {
      alert('Please add at least one item to your order.');
      return;
    }

    const orderItems = Object.values(cart).map(item => `${item.name} x${item.quantity}`).join(', ');
    const totalQuantity = Object.values(cart).reduce((sum, item) => sum + item.quantity, 0);

    const orderData = {
      roomNo: guestInfo.roomNumber,
      customerName: guestInfo.guestName,
      foodItems: orderItems,
      quantity: totalQuantity,
      totalAmount: totals.grandTotal,
      specialInstructions: guestInfo.specialInstructions
    };

    addOrder(orderData); 
    setIsModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setCart({});
    setGuestInfo({ roomNumber: '', guestName: '', specialInstructions: '' });
  };

  if (!foodMenu) {
    return <div className="text-luxury-text text-center pt-32">Loading menu...</div>;
  }

  return (
    <main className="pt-24 pb-16 bg-luxury-bg min-h-screen">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 font-display text-luxury-accent">Room Service</h1>
          <p className="text-luxury-muted max-w-2xl mx-auto">Order delicious food to be delivered directly to your room</p>
          <div className="mt-6 bg-luxury-accent/10 border border-luxury-accent/20 rounded-lg p-4 max-w-2xl mx-auto">
            <p className="text-luxury-accent text-sm"><i className="fas fa-info-circle mr-2"></i>Food ordering is available for hotel guests only. Please have your room number ready.</p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-8 mb-8">
          <h2 className="text-2xl font-bold mb-6 font-display text-luxury-text">Delivery Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormInput label="Room Number *" id="roomNumber" value={guestInfo.roomNumber} onChange={setGuestInfo} />
            <FormInput label="Guest Name *" id="guestName" value={guestInfo.guestName} onChange={setGuestInfo} />
          </div>
          <div className="mt-6">
            <label className="block text-sm font-bold mb-2 text-luxury-muted">Special Instructions</label>
            <textarea
              id="specialInstructions"
              value={guestInfo.specialInstructions}
              onChange={(e) => setGuestInfo(prev => ({...prev, specialInstructions: e.target.value}))}
              className="w-full px-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent placeholder-luxury-border"
              rows="3"
              placeholder="Any special instructions for the chef or delivery..."
            ></textarea>
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          {Object.entries(foodMenu).map(([key, category]) => (
            <FoodCategory
              key={key}
              categoryKey={key}
              category={category}
              isActive={activeCategory === key}
              onToggle={handleCategoryToggle}
              cart={cart}
              onQuantityChange={handleQuantityChange}
            />
          ))}
        </div>
        
        <OrderSummary cart={cart} totals={totals} />

        <div className="max-w-4xl mx-auto flex justify-between mt-8">
          <Link to="/" className="bg-white/5 hover:bg-white/10 text-luxury-text px-8 py-3 rounded-lg font-bold transition">
            <i className="fas fa-arrow-left mr-2"></i>Back to Home
          </Link>
          <button onClick={handlePlaceOrder} className="bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg px-8 py-3 rounded-lg font-bold transition shadow-lg">
            <i className="fas fa-utensils mr-2"></i>Place Order
          </button>
        </div>
      </div>
      
      <OrderConfirmationModal 
        isOpen={isModalOpen} 
        onClose={handleCloseModal} 
        orderData={{...guestInfo, ...totals}} 
      />
    </main>
  );
};

// --- Sub-Components ---

const FormInput = ({ label, id, value, onChange }) => (
  <div>
    <label className="block text-sm font-bold mb-2 text-luxury-muted">{label}</label>
    <input
      type="text"
      id={id}
      value={value}
      onChange={(e) => onChange(prev => ({ ...prev, [id]: e.target.value }))}
      className="w-full px-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent"
      required
    />
  </div>
);

const FoodCategory = ({ categoryKey, category, isActive, onToggle, cart, onQuantityChange }) => (
  <div className={`food-category mb-8 ${isActive ? 'active' : ''}`}>
    <div className="food-category-header bg-luxury-surface border border-luxury-border rounded-xl p-6 cursor-pointer flex items-center hover:border-luxury-accent/50 transition-colors" onClick={() => onToggle(categoryKey)}>
      <h2 className="text-2xl font-bold font-display text-luxury-text flex-grow">{category.name}</h2>
      <span className="text-luxury-muted text-sm font-medium bg-luxury-bg px-3 py-1 rounded-full">{category.time}</span>
      <i className={`fas ${isActive ? 'fa-chevron-up' : 'fa-chevron-down'} ml-4 text-luxury-accent`}></i>
    </div>
    <div className={`food-category-content transition-all duration-500 overflow-hidden ${isActive ? 'max-h-[5000px] mt-6 opacity-100' : 'max-h-0 opacity-0'}`}>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {category.items.map(item => (
          <FoodItem
            key={item.id}
            item={item}
            quantity={cart[item.id]?.quantity || 0}
            onQuantityChange={onQuantityChange}
          />
        ))}
      </div>
    </div>
  </div>
);

const FoodItem = ({ item, quantity, onQuantityChange }) => (
  <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-xl overflow-hidden group">
    <div className="relative">
      <img src={item.image && item.image.startsWith('http') ? item.image : `http://localhost:5000${item.image}`} alt={item.name} className="w-full h-48 object-cover group-hover:scale-105 transition duration-700" />
      <div className="absolute inset-0 bg-gradient-to-t from-luxury-surface via-transparent to-transparent opacity-80"></div>
      <div className="absolute top-4 right-4 bg-luxury-accent text-luxury-bg text-sm font-bold px-3 py-1 rounded-full shadow-lg">
        ₹{item.price}
      </div>
    </div>
    <div className="p-6 relative z-10">
      <h3 className="text-lg font-bold text-luxury-text mb-2">{item.name}</h3>
      <p className="text-luxury-muted text-sm mb-6 line-clamp-2">{item.description || item.desc}</p>
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2 bg-luxury-bg border border-luxury-border rounded-lg p-1">
          <button onClick={() => onQuantityChange(item, quantity - 1)} className="w-8 h-8 flex items-center justify-center text-luxury-accent hover:bg-white/5 rounded transition"><i className="fas fa-minus text-xs"></i></button>
          <input type="number" value={quantity} readOnly className="w-8 text-center bg-transparent text-luxury-text font-bold focus:outline-none hide-arrows" />
          <button onClick={() => onQuantityChange(item, quantity + 1)} className="w-8 h-8 flex items-center justify-center text-luxury-accent hover:bg-white/5 rounded transition"><i className="fas fa-plus text-xs"></i></button>
        </div>
        <span className="text-luxury-accent font-black text-lg">₹{item.price}</span>
      </div>
    </div>
  </div>
);

const OrderSummary = ({ cart, totals }) => (
  <div className="max-w-4xl mx-auto bg-luxury-surface border border-luxury-border rounded-xl shadow-xl p-8 mb-8">
    <h2 className="text-2xl font-bold mb-6 font-display text-luxury-text border-b border-luxury-border pb-4">Order Summary</h2>
    <div className="overflow-x-auto">
      <table className="w-full text-luxury-text">
        <thead>
          <tr className="border-b border-luxury-border text-luxury-muted text-sm">
            <th className="text-left py-3 font-semibold">Item</th>
            <th className="text-center py-3 font-semibold">Quantity</th>
            <th className="text-right py-3 font-semibold">Price</th>
            <th className="text-right py-3 font-semibold">Subtotal</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-luxury-border/50">
          {Object.keys(cart).length === 0 ? (
            <tr><td colSpan="4" className="py-6 text-center text-luxury-muted italic">No items selected</td></tr>
          ) : (
            Object.values(cart).map(item => (
              <tr key={item.id} className="text-sm">
                <td className="py-4 font-medium">{item.name}</td>
                <td className="py-4 text-center">{item.quantity}</td>
                <td className="py-4 text-right text-luxury-muted">₹{item.price.toLocaleString()}</td>
                <td className="py-4 text-right font-bold">₹{(item.price * item.quantity).toLocaleString()}</td>
              </tr>
            ))
          )}
        </tbody>
        <tfoot className="border-t-2 border-luxury-border mt-2">
          <tr className="text-sm text-luxury-muted">
            <td colSpan="3" className="py-3 text-right">Food Total:</td>
            <td className="py-3 text-right text-luxury-text font-medium">₹{totals.foodTotal.toLocaleString()}</td>
          </tr>
          <tr className="text-sm text-luxury-muted">
            <td colSpan="3" className="py-1 text-right border-b border-luxury-border pb-4">Room Service Charge ({(SERVICE_CHARGE_RATE * 100).toFixed(0)}%):</td>
            <td className="py-1 text-right text-luxury-text font-medium border-b border-luxury-border pb-4">₹{totals.serviceCharge.toLocaleString()}</td>
          </tr>
          <tr className="text-xl font-black text-luxury-accent">
            <td colSpan="3" className="py-4 text-right">Grand Total:</td>
            <td className="py-4 text-right">₹{totals.grandTotal.toLocaleString()}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
);

const OrderConfirmationModal = ({ isOpen, onClose, orderData }) => {
  if (!isOpen) return null;
  const estimatedTime = Math.floor(Math.random() * 30) + 20;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-luxury-surface border border-luxury-border rounded-xl shadow-2xl max-w-md w-full p-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-luxury-accent"></div>
        <div className="text-center">
          <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/20 shadow-[0_0_30px_rgba(34,197,94,0.1)]">
            <i className="fas fa-check text-green-400 text-3xl"></i>
          </div>
          <h3 className="text-3xl font-bold font-display text-luxury-text mb-2">Order Confirmed!</h3>
          <p className="text-luxury-muted mb-6">Your culinary experience is being prepared.</p>
          
          <div className="bg-luxury-bg border border-luxury-border rounded-lg p-5 mb-6 text-sm text-luxury-text space-y-3 text-left">
            <div className="flex justify-between"><span className="text-luxury-muted">Room Number:</span><span className="font-bold">{orderData.roomNumber}</span></div>
            <div className="flex justify-between"><span className="text-luxury-muted">Guest Name:</span><span className="font-bold">{orderData.guestName}</span></div>
            <div className="flex justify-between"><span className="text-luxury-muted">Estimated Delivery:</span><span className="font-bold text-luxury-accent">{estimatedTime} minutes</span></div>
            <div className="flex justify-between font-black text-lg pt-3 border-t border-luxury-border mt-3">
              <span>Total Amount:</span><span className="text-luxury-accent">₹{orderData.grandTotal.toLocaleString()}</span>
            </div>
          </div>
          
          <p className="text-xs text-luxury-muted mb-8 leading-relaxed">
            <i className="fas fa-info-circle mr-1 text-luxury-accent"></i>
            Your order will be delivered to Room {orderData.roomNumber}. The amount has been charged to your room folio.
          </p>
          <button onClick={onClose} className="w-full bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg py-4 rounded-lg font-bold transition shadow-lg">
            Close window
          </button>
        </div>
      </div>
    </div>
  );
};

export default Order;