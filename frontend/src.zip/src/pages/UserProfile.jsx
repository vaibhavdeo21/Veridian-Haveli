import React, { useState, useMemo } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useData } from '../context/DataContext.jsx';
import ChangePasswordModal from '../components/ChangePasswordModal.jsx';

const UserProfile = () => {
  const { user } = useAuth();
  const { customers } = useData();
  
  const [activeTab, setActiveTab] = useState('stays');
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const { currentStays, upcomingStays, pastStays } = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const userBookings = customers.filter(c => 
      c.email === user.email || 
      c.username === user.username ||
      (c.guestName && c.guestName.toLowerCase().includes(user.username.toLowerCase()))
    );

    const current = [];
    const upcoming = [];
    const past = [];

    userBookings.forEach(booking => {
      const checkOutDate = new Date(booking.checkOutDate);
      const normalizedStatus = (booking.status || 'Booked').replace(/\s/g, "").toLowerCase();

      if (normalizedStatus === 'checkedin') {
        current.push(booking);
      } 
      else if (normalizedStatus === 'checkedout' || normalizedStatus === 'cancelled') {
        past.push(booking);
      } 
      else if (normalizedStatus === 'booked') {
        if (checkOutDate < today) {
          past.push(booking);
        } else {
          upcoming.push(booking);
        }
      }
    });

    upcoming.sort((a, b) => new Date(a.checkInDate) - new Date(b.checkInDate));
    past.sort((a, b) => new Date(b.checkInDate) - new Date(a.checkInDate));

    return { currentStays: current, upcomingStays: upcoming, pastStays: past };
  }, [customers, user]);

  const calculateFinancials = (booking) => {
    const roomTotalIncGST = booking.totalAmount || 0; 
    const foodTotal = booking.foodCharges || 0;
    const foodGST = foodTotal * 0.18;
    const lateNightFee = booking.lateNightFee || 0;
    const checkOutLateFee = booking.lateFee || 0;
    
    const grandTotal = roomTotalIncGST + foodTotal + foodGST + lateNightFee + checkOutLateFee;
    const amountPaid = booking.amountPaid || 0;
    const balance = grandTotal - amountPaid;

    return { roomTotalIncGST, foodTotal, foodGST, lateNightFee, checkOutLateFee, grandTotal, amountPaid, balance };
  };

  return (
    <main className="pt-28 pb-16 bg-luxury-bg min-h-screen">
      <div className="max-w-6xl mx-auto px-4">
        
        {/* Header Section */}
        <div className="bg-luxury-surface rounded-2xl shadow-xl p-8 mb-8 flex items-center justify-between border border-luxury-border">
          <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-luxury-accent/20 text-luxury-accent rounded-full flex items-center justify-center text-4xl font-bold shadow-inner">
              <i className="fas fa-user"></i>
            </div>
            <div>
              <h1 className="text-3xl font-display font-bold text-luxury-text">Welcome, <span className="text-luxury-accent">{user.username}</span></h1>
              <p className="text-luxury-muted font-medium mt-1">{user.email || 'Manage your bookings and account settings'}</p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-2 mb-8 border-b-2 border-luxury-border">
          <button 
            onClick={() => setActiveTab('stays')}
            className={`px-6 py-3 font-bold text-lg transition-colors border-b-4 ${activeTab === 'stays' ? 'border-luxury-accent text-luxury-accent' : 'border-transparent text-luxury-muted hover:text-luxury-text'}`}
          >
            <i className="fas fa-bed mr-2"></i> My Stays
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`px-6 py-3 font-bold text-lg transition-colors border-b-4 ${activeTab === 'settings' ? 'border-luxury-accent text-luxury-accent' : 'border-transparent text-luxury-muted hover:text-luxury-text'}`}
          >
            <i className="fas fa-cog mr-2"></i> Account Settings
          </button>
        </div>

        {/* --- STAYS TAB --- */}
        {activeTab === 'stays' && (
          <div className="space-y-12 animate-fadeIn">
            
            {/* Current Stay */}
            {currentStays.length > 0 && (
              <section>
                <h2 className="text-2xl font-bold text-green-400 mb-6 flex items-center">
                  <i className="fas fa-key mr-3"></i> Current Stay
                </h2>
                <div className="grid gap-6">
                  {currentStays.map(booking => <StayCard key={booking._id || booking.id} booking={booking} financials={calculateFinancials(booking)} type="current" />)}
                </div>
              </section>
            )}

            {/* Upcoming Stays */}
            <section>
              <h2 className="text-2xl font-bold text-luxury-accent mb-6 flex items-center">
                <i className="fas fa-calendar-alt mr-3"></i> Upcoming Bookings
              </h2>
              {upcomingStays.length > 0 ? (
                <div className="grid gap-6">
                  {upcomingStays.map(booking => <StayCard key={booking._id || booking.id} booking={booking} financials={calculateFinancials(booking)} type="upcoming" />)}
                </div>
              ) : (
                <div className="bg-luxury-surface p-12 rounded-xl border border-dashed border-luxury-border text-center text-luxury-muted font-medium">
                  <i className="fas fa-suitcase-rolling text-4xl mb-4 opacity-50 block"></i>
                  You have no upcoming bookings. <a href="/booking" className="text-luxury-accent hover:text-luxury-accentHover underline ml-1">Book a room now</a>
                </div>
              )}
            </section>

            {/* Past Stays */}
            {pastStays.length > 0 && (
              <section>
                <h2 className="text-xl font-bold text-luxury-muted mb-6 flex items-center">
                  <i className="fas fa-history mr-3"></i> Past Bookings
                </h2>
                <div className="grid gap-6 opacity-75 hover:opacity-100 transition-opacity">
                  {pastStays.map(booking => <StayCard key={booking._id || booking.id} booking={booking} financials={calculateFinancials(booking)} type="past" />)}
                </div>
              </section>
            )}
          </div>
        )}

        {/* --- SETTINGS TAB --- */}
        {activeTab === 'settings' && (
          <div className="bg-luxury-surface rounded-2xl shadow-xl p-8 border border-luxury-border animate-fadeIn max-w-2xl">
            <h2 className="text-2xl font-bold text-luxury-text mb-8 border-b border-luxury-border pb-4">Security & Authentication</h2>
            
            <div className="space-y-8">
              <div>
                <label className="block text-sm font-bold text-luxury-muted uppercase tracking-wide mb-2">Username</label>
                <div className="text-lg font-medium text-luxury-text bg-luxury-bg px-4 py-3 rounded-lg border border-luxury-border">
                  {user.username}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-bold text-luxury-muted uppercase tracking-wide mb-3">Password Management</label>
                <button 
                  onClick={() => setIsPasswordModalOpen(true)}
                  className="bg-white/10 hover:bg-white/20 text-luxury-text border border-luxury-border px-6 py-3 rounded-lg font-bold transition-all shadow-sm flex items-center"
                >
                  <i className="fas fa-lock mr-2 text-luxury-accent"></i> Change Password
                </button>
                <p className="text-xs text-luxury-muted mt-3">Regularly update your password to keep your account secure.</p>
              </div>
            </div>
          </div>
        )}

      </div>

      <ChangePasswordModal 
        isOpen={isPasswordModalOpen} 
        onClose={() => setIsPasswordModalOpen(false)} 
      />
    </main>
  );
};

const StayCard = ({ booking, financials, type }) => {
  const { roomTotalIncGST, foodTotal, lateNightFee, grandTotal, amountPaid, balance } = financials;
  
  const statusColors = {
    current: 'bg-green-500/10 text-green-400 border-green-500/20 shadow-[0_0_15px_rgba(34,197,94,0.1)]',
    upcoming: 'bg-luxury-accent/10 text-luxury-accent border-luxury-accent/20',
    past: 'bg-luxury-bg text-luxury-muted border-luxury-border'
  };

  const statusText = {
    current: 'CHECKED IN',
    upcoming: 'CONFIRMED',
    past: 'COMPLETED'
  };

  return (
    <div className={`bg-luxury-surface rounded-xl shadow-xl overflow-hidden flex flex-col md:flex-row border border-luxury-border ${type === 'current' ? 'ring-1 ring-green-500/50' : ''}`}>
      
      {/* Left: Room Details */}
      <div className="p-8 md:w-1/3 bg-luxury-bg/50 flex flex-col justify-center border-r border-luxury-border">
        <span className={`self-start px-3 py-1 rounded-full text-xs font-black tracking-widest uppercase border mb-4 ${statusColors[type]}`}>
          {statusText[type]}
        </span>
        <h3 className="text-2xl font-black text-luxury-text mb-2 font-display">
          {booking.roomNumber?.includes('Online') ? booking.roomNumber.replace('Online-', '') + ' Room' : `Room ${booking.roomNumber}`}
        </h3>
        <p className="text-xs text-luxury-muted font-mono bg-luxury-bg px-2 py-1 rounded inline-block self-start border border-luxury-border">ID: {booking._id || booking.id}</p>
        
        {type === 'upcoming' && booking.paymentMode === 'PayAtHotel' && (
          <div className="mt-6 bg-red-500/10 text-red-400 p-3 rounded-lg text-xs font-bold border border-red-500/20">
            <i className="fas fa-exclamation-circle mr-1"></i> Pay at Hotel selected. Room is subject to availability upon arrival.
          </div>
        )}
      </div>

      {/* Middle: Dates */}
      <div className="p-8 md:w-1/3 flex flex-col justify-center border-b md:border-b-0 md:border-r border-luxury-border relative">
        <div className="flex justify-between items-center relative z-10">
          <div>
            <p className="text-xs font-black text-luxury-muted uppercase tracking-widest mb-2">Check-in</p>
            <p className="font-bold text-luxury-text text-lg">{new Date(booking.checkInDate).toLocaleDateString('en-GB')}</p>
            <p className="text-xs text-luxury-muted mt-1">12:00 PM</p>
          </div>
          <i className="fas fa-long-arrow-alt-right text-luxury-accent/30 text-3xl"></i>
          <div className="text-right">
            <p className="text-xs font-black text-luxury-muted uppercase tracking-widest mb-2">Check-out</p>
            <p className="font-bold text-luxury-text text-lg">{new Date(booking.checkOutDate).toLocaleDateString('en-GB')}</p>
            <p className="text-xs text-luxury-muted mt-1">11:00 AM</p>
          </div>
        </div>
      </div>

      {/* Right: Financials */}
      <div className="p-8 md:w-1/3 flex flex-col justify-center bg-luxury-surface">
        <div className="space-y-3 mb-6">
          <div className="flex justify-between text-sm">
            <span className="text-luxury-muted">Room (Inc. GST):</span>
            <span className="font-medium text-luxury-text">₹{roomTotalIncGST.toLocaleString()}</span>
          </div>
          {foodTotal > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-luxury-muted">Food/Services:</span>
              <span className="font-medium text-luxury-text">₹{foodTotal.toLocaleString()}</span>
            </div>
          )}
          {lateNightFee > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-luxury-muted">Late Night Fee:</span>
              <span className="font-medium text-luxury-text">₹{lateNightFee.toLocaleString()}</span>
            </div>
          )}
        </div>
        
        <div className="border-t border-luxury-border pt-4 mb-4 space-y-2">
          <div className="flex justify-between font-black text-luxury-text">
            <span>Total Bill:</span>
            <span>₹{grandTotal.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
          </div>
          <div className="flex justify-between font-medium text-sm text-green-400">
            <span>Amount Paid:</span>
            <span>- ₹{amountPaid.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
          </div>
        </div>

        <div className={`p-4 rounded-lg flex justify-between font-black text-lg border ${balance > 0 ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-green-500/10 text-green-400 border-green-500/20'}`}>
          <span>Balance:</span>
          <span>₹{Math.max(0, balance).toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
        </div>
      </div>

    </div>
  );
};

export default UserProfile;