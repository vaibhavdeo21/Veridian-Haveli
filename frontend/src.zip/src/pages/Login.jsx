import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const Login = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const { login, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      if (user.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    }
  }, [user, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    login(credentials);
  };

  return (
    <main className="pt-32 pb-16 min-h-screen bg-luxury-bg flex items-center justify-center">
      <div className="bg-luxury-surface border border-luxury-border p-8 rounded-2xl shadow-2xl max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-luxury-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-user-circle text-luxury-accent text-3xl"></i>
          </div>
          <h2 className="text-3xl font-bold font-display text-luxury-text">Welcome Back</h2>
          <p className="text-luxury-muted mt-2">Log in to manage your bookings and orders</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold mb-1 text-luxury-muted">Username</label>
            <div className="relative">
              <i className="fas fa-user absolute left-4 top-3.5 text-luxury-muted"></i>
              <input 
                type="text" 
                className="w-full pl-10 pr-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent"
                placeholder="Enter username (e.g., admin)"
                value={credentials.username}
                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1 text-luxury-muted">Password</label>
            <div className="relative">
              <i className="fas fa-lock absolute left-4 top-3.5 text-luxury-muted"></i>
              <input 
                type="password" 
                className="w-full pl-10 pr-4 py-3 bg-luxury-bg border border-luxury-border text-luxury-text rounded-lg focus:outline-none focus:border-luxury-accent focus:ring-1 focus:ring-luxury-accent"
                placeholder="Enter password"
                value={credentials.password}
                onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                required
              />
            </div>
          </div>
          <button 
            type="submit" 
            className="w-full bg-luxury-accent hover:bg-luxury-accentHover text-luxury-bg font-bold py-3 px-4 rounded-lg transition duration-300 flex items-center justify-center mt-4 shadow-lg"
          >
            <i className="fas fa-sign-in-alt mr-2"></i> Log In
          </button>
        </form>
        
        <div className="mt-6 text-center text-sm text-luxury-muted border-t border-luxury-border pt-6">
          Don't have an account yet? <br/>
          <Link to="/register" className="text-luxury-accent font-bold hover:text-luxury-accentHover mt-2 inline-block transition">Create an Account</Link>
        </div>
      </div>
    </main>
  );
};

export default Login;